<?php 
if(! function_exists('asset_url()')){
	function asset_url(){
		return base_url().'assets/';
	}
}
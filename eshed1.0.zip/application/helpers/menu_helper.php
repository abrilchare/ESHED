<?php 
if(!function_exists('active_link')){
	function activate_menu($controller){
    	$CI = get_instance();
    	$class = $CI->router->fetch_method();
    	return ($class == $controller) ? 'active' : '';
	}
}
?>
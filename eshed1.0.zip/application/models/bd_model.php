<?php
class bd_model extends CI_Model{
    public function __construct(){
        parent::__construct();
    }
    public function getQuery($table){
    	$query = $this->db->get($table);
    	if($query->num_rows() > 0 ){
            return $query->result();
        }
        else{
            return null;
        }
    }
    public function getInsert($table, $data){
		$this->db->insert($table, $data);
		return true;
	}
	public function whereQuery($table, $select, $where){
		$query = $this->db->where($select, $where);
		$query = $this->db->get($table);
        if($query->num_rows() > 0 ){
        	return $query->result();
        }
        else{
            return null;
        }
    }
    public function getUpdate($table, $select, $where, $data){
		$query = $this->db->where($select, $where);
		$this->db->set($data);
		return $this->db->update($table);
	}
	public function getDelete($table, $select, $where){
		$query = $this->db->where($select, $where);
    	$this->db->delete($table);
	}
    public function getLogin($table, $select, $online, $username, $password){
        $query = $this->db->where($select, $username);
        $query = $this->db->get($table);
        if($query->num_rows() == 1){
            $row=$query->row();
            if($password == $row->password && $online == $row->status)
            {
                $this->session->set_userdata('user_data', $username);
                $this->session->set_userdata('first_name', $row->firt_name);
                $this->session->set_userdata('last_name', $row->last_name);
                $this->session->set_userdata('rol_user', $row->rol);
                echo $this->session->userdata('user_data');
                echo $this->session->userdata('first_name');
                echo $this->session->userdata('last_name');
                echo $this->session->userdata('rol_user');
                return true;
            }
            echo $this->session->unset_userdata('user_data');
            return false;
        }
    }

    
}
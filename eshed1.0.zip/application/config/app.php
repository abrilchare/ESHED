<?php  
$config['software']	= 'ESHED';
$config['version']	= '1.0.0';
$config['update']	= '1.0.0';
$config['description']	= 'System of ...';
$config['author']	= 'Eng. Abril Chávez';
<?php
$autoload['packages'] = array();
$autoload['libraries'] = array();
$autoload['drivers'] = array();
$autoload['helper'] = array('form', 'url', 'utility', 'menu', 'access');
$autoload['config'] = array('app');
$autoload['language'] = array();
$autoload['model'] = array('bd_model');
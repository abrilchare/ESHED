<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <meta name="description" content="<?php echo $this->config->item("description");?>">
  <meta name="author" content="<?php echo $this->config->item("author");?>">
  <link rel="shortcut icon" href="<?php echo asset_url();?>images/favicon.png" type="image/png">
  <title><?php echo $this->config->item("software");?> <?php echo $this->config->item("version");?></title>
  <link rel="stylesheet" href="<?php echo asset_url();?>lib/fontawesome/css/font-awesome.css">
  <link rel="stylesheet" href="<?php echo asset_url();?>css/quirk.css">
  <script src="<?php echo asset_url();?>lib/modernizr/modernizr.js"></script>
</head>
<body class="signwrapper">
  <div class="sign-overlay"></div>
  <div class="signpanel"></div>

  <div class="panel signin">
    <div class="panel-heading">
      <h1><img src="<?php echo asset_url();?>images/logo.png" alt="" /></h1>
      <h4 class="panel-title">Welcome! Please signin.</h4>
    </div>
    <div class="panel-body">
      <form id="login" method="post" action="<?php echo base_url('backend/login');?>">
        <div class="form-group mb10">
          <div class="input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
            <input type="text" name="username" class="form-control" value="admin" placeholder="Enter Username">
          </div>
        </div>
        <div class="form-group nomargin">
          <div class="input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
            <input type="password" name="password" class="form-control" value="admin" placeholder="Enter Password">
          </div>
        </div>
        <!--<div><a href="" class="forgot">Forgot password?</a></div>-->
        <div class="form-group">
          <button class="btn btn-success btn-quirk btn-block">Sign In</button>
        </div>
      </form>
      <hr class="invisible">
      <div align="center"><?php echo "Copiryght &copy; 2018 ".$this->config->item("author");?></div>
    </div>
  </div>
</body>
</html>

  <link rel="stylesheet" href="<?php echo asset_url();?>lib/Hover/hover.css">
  <link rel="stylesheet" href="<?php echo asset_url();?>lib/fontawesome/css/font-awesome.css">
  <link rel="stylesheet" href="<?php echo asset_url();?>lib/weather-icons/css/weather-icons.css">
  <link rel="stylesheet" href="<?php echo asset_url();?>lib/ionicons/css/ionicons.css">
  <link rel="stylesheet" href="<?php echo asset_url();?>lib/jquery-toggles/toggles-full.css">
  <link rel="stylesheet" href="<?php echo asset_url();?>lib/morrisjs/morris.css">
  <link rel="stylesheet" href="<?php echo asset_url();?>css/quirk.css">
  <script src="<?php echo asset_url();?>lib/modernizr/modernizr.js"></script>
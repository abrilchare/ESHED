<script src="<?php echo asset_url();?>lib/jquery/jquery.js"></script>
<script src="<?php echo asset_url();?>lib/bootstrap/js/bootstrap.js"></script>
<script src="<?php echo asset_url();?>lib/jquery-toggles/toggles.js"></script>
<script src="<?php echo asset_url();?>lib/select2/select2.js"></script>
<script src="<?php echo asset_url();?>lib/jquery-validate/jquery.validate.js"></script>
<script src="<?php echo asset_url();?>js/quirk.js"></script>
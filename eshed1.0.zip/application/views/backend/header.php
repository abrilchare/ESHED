<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <meta name="description" content="<?php echo $this->config->item("description");?>">
  <meta name="author" content="<?php echo $this->config->item("author");?>">
  <link rel="shortcut icon" href="<?php echo asset_url();?>images/favicon.png" type="image/png">
  <title><?php echo $this->config->item("software");?> <?php echo $this->config->item("version");?></title>
  <?php $this->load->view($style);?>
</head>
<body>
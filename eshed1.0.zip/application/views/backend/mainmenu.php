            <li class="<?php echo activate_menu('dashboard'); ?>">
              <a href="<?php echo site_url('backend/dashboard');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('dashboard');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('publication'); ?>">
              <a href="<?php echo site_url('backend/publication');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('publication');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('articles'); ?>">
              <a href="<?php echo site_url('backend/articles');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('articles');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('books'); ?>">
              <a href="<?php echo site_url('backend/books');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('books');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('chapter'); ?>">
              <a href="<?php echo site_url('backend/chapter');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('chapter');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('memoirs'); ?>">
              <a href="<?php echo site_url('backend/memoirs');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('memoirs');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('inception'); ?>">
              <a href="<?php echo site_url('backend/inception');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('inception');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('serial'); ?>">
              <a href="<?php echo site_url('backend/serial');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('serial');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('reports'); ?>">
              <a href="<?php echo site_url('backend/reports');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('reports');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('user'); ?>">
              <a href="<?php echo site_url('backend/user');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('user');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('profile'); ?>">
              <a href="<?php echo site_url('backend/profile');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('profile');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('academy'); ?>">
              <a href="<?php echo site_url('backend/academy');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('academy');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('rol'); ?>">
              <a href="<?php echo site_url('backend/rol');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('rol');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('permission'); ?>">
              <a href="<?php echo site_url('backend/permission');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('permission');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('countries'); ?>">
              <a href="<?php echo site_url('backend/countries');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('countries');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('logs'); ?>">
              <a href="<?php echo site_url('backend/logs');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('logs');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('backups'); ?>">
              <a href="<?php echo site_url('backend/backups');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('backups');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('updates'); ?>">
              <a href="<?php echo site_url('backend/updates');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('updates');?>
                </span>
              </a>
            </li>
            <li class="<?php echo activate_menu('settings'); ?>">
              <a href="<?php echo site_url('backend/settings');?>">
                <i class="fa fa-home"></i>
                <span>
                  <?php echo $this->lang->line('settings');?>
                </span>
              </a>
            </li>
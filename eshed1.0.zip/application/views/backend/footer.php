<?php $this->load->view($script);?>
</body>
</html>
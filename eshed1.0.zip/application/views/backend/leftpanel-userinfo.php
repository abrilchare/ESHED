      <div class="leftpanel-userinfo collapse" id="loguserinfo">
        <h5 class="sidebar-title">
          <?php 
            echo $this->config->item("software")." ".$this->config->item("version");
            echo "<br>";
            echo $this->config->item("description");
            echo "<br>";
            echo "By: ".$this->config->item("author");
          ?>
        </h5>
      </div><!-- leftpanel-userinfo -->
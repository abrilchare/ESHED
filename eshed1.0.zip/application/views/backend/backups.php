    <div class="contentpanel">

      <div class="row">
        <div class="col-md-3 col-lg-4 dash-right">
          <div class="row">
            <div class="col-sm-5 col-md-12 col-lg-6">
              <div class="panel panel-primary list-announcement">
                <div class="panel-heading">
                  <h4 class="panel-title">Backups</h4>
                </div>
                <div class="panel-body">
                  <ul class="list-unstyled mb20">
                    <li>
                      <?php 
                        $path = opendir("backups");
                        while ($file = readdir($path)){
                          if (is_dir($file)){
                            echo $file . "<br />";
                          }
                          else{
                            echo $file . "<br />";
                          }
                        }
                      ?>
                    </li>
                  </ul>
                </div>
                <div class="panel-footer">
                  <div class="btn-group">
                    <a class="btn btn-primary btn" href="<?php echo site_url('backend/new_backup');?>">New Backup</a>
                  </div>
                </div>
              </div>
            </div><!-- col-md-12 -->
          </div><!-- row -->
        </div><!-- col-md-3 -->
      </div><!-- row -->

    </div><!-- contentpanel -->
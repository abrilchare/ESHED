    <div class="contentpanel">

      <ol class="breadcrumb breadcrumb-quirk">
        <li><a href="<?php echo base_url('backend/dashboard');?>"><i class="fa fa-home mr5"></i> HOME</a></li>
        <li class="active"><?php echo $this->lang->line('permission');?></li>
      </ol>

      <div class="panel">
        <div class="panel-heading">
          <div class="btn-group">
            <a class="btn btn-primary btn-xs" href="<?php echo site_url('backend/add_permission');?>">Add</a>
          </div><!-- btn-group -->
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table nomargin">
              <thead>
                <tr>
                  <th class="text-center">
                    <label class="ckbox ckbox-primary">
                      <input type="checkbox"><span></span>
                    </label>
                  </th>
                  <th>Name</th>
                  <th>Position</th>
                  <th>Office</th>
                  <th class="text-center">Age</th>
                  <th class="text-right">Start date</th>
                  <th class="text-right">Salary</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>

              <?php
                if(!empty($query)){
                  $no = 1; 
                  foreach($query as $row){
              ?>
                <tr>
                  <td class="text-center">
                    <label class="ckbox ckbox-primary">
                      <input type="checkbox"><span></span>
                    </label>
                  </td>
                  <td><?=$row->content?></td>
                  <td><?=$row->rol?></td>                  
                  <td>
                    <ul class="table-options">
                      <li><a href="<?php echo base_url('backend/edit_permission?id='.$row->content);?>"><i class="fa fa-pencil"></i></a></li>
                      <li><a href="<?php echo base_url('backend/delete_permission?id='.$row->content);?>"><i class="fa fa-trash"></i></a></li>
                    </ul>
                  </td>
                </tr>
              <?php
                  $no++;
                  }
                } 
                else { ?>
                <tr><td class="text-center"></td></tr>
                <?php  
                }
              ?>
              </tbody>
            </table>
          </div><!-- table-responsive -->
        </div>
      </div><!-- panel -->
    </div><!-- contentpanel -->
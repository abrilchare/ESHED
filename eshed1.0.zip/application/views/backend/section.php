<section>
  <div class="leftpanel">
    <div class="leftpanelinner">
      <?php $this->load->view('backend/leftpanel-profile');?>
      <?php $this->load->view('backend/leftpanel-userinfo');?>
      <?php $this->load->view('backend/nav-tabs');?>
      <div class="tab-content">
        <div class="tab-pane active" id="mainmenu">
          <h5 class="sidebar-title"><?php echo $this->lang->line('main_menu');?></h5>
          <ul class="nav nav-pills nav-stacked nav-quirk">
            <?php 
              $this->load->view('backend/mainmenu');
            ?>
          </ul>
        </div>
        <?php $this->load->view('backend/emailmenu');?>
        <?php $this->load->view('backend/contactmenu');?>
        <?php $this->load->view('backend/settingsmenu');?>
      </div>
    </div>
  </div>
  <div class="mainpanel">
    <?php $this->load->view($link);?>
  </div>
</section>
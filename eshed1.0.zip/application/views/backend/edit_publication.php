    <div class="contentpanel">

      <ol class="breadcrumb breadcrumb-quirk">
        <li><a href="index.html"><i class="fa fa-home mr5"></i> Home</a></li>
        <li><a href="general-forms.html">Forms</a></li>
        <li class="active">Form Wizards</li>
      </ol>

      <div class="row">

        <div class="col-md-8">
          <div class="panel">
              <div class="panel-heading nopaddingbottom">
                <h4 class="panel-title">Basic Form Validation</h4>
                <p>Please provide your name, email address (won't be published) and a comment.</p>
              </div>
              <div class="panel-body">
                <hr>
                <form id="update_publication" method="post" action="<?php echo base_url('backend/update_publication');?>" class="form-horizontal">
                  <?php foreach($query as $row){ ?>
                  <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo $this->lang->line('idp');?> <span class="text-danger">*</span></label>
                    <div class="col-sm-8">
                      <input type="text" name="idp" class="form-control" value="<?=$row->idp?>" required />
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo $this->lang->line('title');?> <span class="text-danger">*</span></label>
                    <div class="col-sm-8">
                      <input type="text" name="title" class="form-control" value="<?=$row->title?>" required />
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo $this->lang->line('description');?></label>
                    <div class="col-sm-8">
                      <input type="text" name="description" class="form-control" value="<?=$row->description?>"/>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo $this->lang->line('keyworks');?> <span class="text-danger">*</span></label>
                    <div class="col-sm-8">
                     <input type="text" name="keyworks" class="form-control" value="<?=$row->keyworks?>"/>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo $this->lang->line('year');?> <span class="text-danger">*</span></label>
                    <div class="col-sm-8">
                      <input type="text" minlength="4" maxlength="4" name="year" class="form-control" value="<?=$row->year?>" required />
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo $this->lang->line('pages');?> <span class="text-danger">*</span></label>
                    <div class="col-sm-8">
                      <input type="text" name="pages" class="form-control" value="<?=$row->pages?>" required />
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo $this->lang->line('book');?> <span class="text-danger">*</span></label>
                    <div class="col-sm-8">
                      <input type="text" name="book" class="form-control" value="<?=$row->book?>" required />
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo $this->lang->line('publisher');?> <span class="text-danger">*</span></label>
                    <div class="col-sm-8">
                      <input type="text" name="publisher" class="form-control" value="<?=$row->publisher?>" required />
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo $this->lang->line('authors');?> <span class="text-danger">*</span></label>
                    <div class="col-sm-8">
                      <input type="text" name="authors" class="form-control" placeholder="<?php echo $this->lang->line('ph_authors');?>" required />
                    </div>
                  </div>
                  <?php } ?>
                  <hr>

                  <div class="row">
                    <div class="col-sm-9 col-sm-offset-3">
                      <button class="btn btn-success btn-quirk btn-wide mr5"><?php echo $this->lang->line('btn_save');?></button>
                    </div>
                  </div>

                </form>
              </div><!-- panel-body -->
          </div><!-- panel -->

        </div><!-- col-md-6 -->


        <div class="col-md-4">
          <div class="panel panel-inverse-full">
            <div class="panel-heading">
              <h3 class="panel-title">Documentation for help</h3>
            </div>
            <div class="panel-body">
              <p class="nomargin">Write is here step for help to user.</p>
            </div>
          </div><!-- panel -->
          <div class="panel panel-info-full">
            <div class="panel-heading">
              <h3 class="panel-title">Documentation for help</h3>
            </div>
            <div class="panel-body">
              <p class="nomargin">Write is here step for help to user.</p>
            </div>
          </div><!-- panel -->
          <div class="panel panel-danger-full">
            <div class="panel-heading">
              <h3 class="panel-title">Documentation for help</h3>
            </div>
            <div class="panel-body">
              <p class="nomargin">Write is here step for help to user.</p>
            </div>
          </div><!-- panel -->
        </div><!-- col-md-6 -->

      </div><!--row -->


    </div><!-- contentpanel -->
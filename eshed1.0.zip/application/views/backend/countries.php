    <div class="contentpanel">

      <ol class="breadcrumb breadcrumb-quirk">
        <li><a href="index.html"><i class="fa fa-home mr5"></i> Home</a></li>
        <li><a href="basic-tables.html">Tables</a></li>
        <li class="active">Basic Tables</li>
      </ol>

      <div class="panel">
        <div class="panel-heading">
          <h4 class="panel-title">Basic Styling</h4>
          <p>For basic styling add the base class <code>.table</code> to any table.</p>
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table id="tableCountries" class="table table-bordered table-striped-col">
              <thead>
                <tr>
                  <th class="text-center">
                    <label class="ckbox ckbox-primary">
                      <input type="checkbox"><span></span>
                    </label>
                  </th>
                  <th>Name</th>
                  <th>Alpha2</th>
                  <th>Numeric</th>
                  <th>Currency</th>
                  <th>Symbol</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
              <?php
                foreach($query as $row){
              ?>
                <tr>
                  <td class="text-center">
                    <label class="ckbox ckbox-primary">
                      <input type="checkbox"><span></span>
                    </label>
                  </td>
                  <td><?=$row->name?></td>
                  <td><?=$row->iso_alpha2?></td>
                  <td><?=$row->iso_numeric?></td>
                  <td><?=$row->currency_code?></td>
                  <td><?=$row->currrency_symbol?></td>
                  <td>
                    <ul class="table-options">
                      <li><a href=""><i class="fa fa-pencil"></i></a></li>
                      <li><a href=""><i class="fa fa-trash"></i></a></li>
                    </ul>
                  </td>
                </tr>
              <?php
                }
              ?>
              </tbody>
            </table>
          </div><!-- table-responsive -->
        </div>
      </div><!-- panel -->
    </div><!-- contentpanel -->
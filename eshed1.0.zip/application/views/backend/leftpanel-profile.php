      <div class="media leftpanel-profile">
        <div class="media-left">
          <a href="#">
            <img src="<?php echo asset_url();?>images/photos/user.jpg" alt="" class="media-object img-circle">
          </a>
        </div>
        <div class="media-body">
          <h4 class="media-heading">
          <?php 
            $first_name = $this->session->userdata('first_name');
            $last_name = $this->session->userdata('last_name');
            echo $first_name. " ".$last_name;
          ?>
           <a data-toggle="collapse" data-target="#loguserinfo" class="pull-right"><i class="fa fa-angle-down"></i></a></h4>
          <span>
            <?php 
              echo $this->session->userdata('rol_user');
            ?>
          </span>
        </div>
      </div><!-- leftpanel-profile -->
    <div class="contentpanel">

      <div class="row">
        <div class="col-md-3 col-lg-4 dash-right">
          <div class="row">
            <div class="col-sm-5 col-md-12 col-lg-6">
              <div class="panel panel-primary list-announcement">
                <div class="panel-heading">
                  <h4 class="panel-title">Update</h4>
                </div>
                <div class="panel-body">
                  <ul class="list-unstyled mb20">
                    <li>
                      <?php echo "Current Version: ".$this->config->item("software");?> <?php echo $this->config->item("version");?>
                    </li>
                    <li>
                      <?php echo "Last Version: ".$this->config->item("software");?> <?php echo $this->config->item("update");?>
                    </li>
                  </ul>
                </div>
                <div class="panel-footer">
                  <div class="btn-group">
                    <a class="btn btn-primary btn" href="<?php echo site_url('backend/update_check');?>">Check Now</a>
                  </div>
                  <div class="btn-group">
                    <a class="btn btn-primary btn" href="<?php echo site_url('backend/update_now');?>">Update</a>
                  </div>
                </div>
              </div>
            </div><!-- col-md-12 -->
          </div><!-- row -->
        </div><!-- col-md-3 -->
      </div><!-- row -->

    </div><!-- contentpanel -->
    <div class="contentpanel">

      <ol class="breadcrumb breadcrumb-quirk">
        <li><a href="index.html"><i class="fa fa-home mr5"></i> Home</a></li>
        <li><a href="general-forms.html">Forms</a></li>
        <li class="active">Form Wizards</li>
      </ol>

      <div class="row">

        <div class="col-md-8">
          <div class="panel">
              <div class="panel-heading nopaddingbottom">
                <h4 class="panel-title">Basic Form Validation</h4>
                <p>Please provide your name, email address (won't be published) and a comment.</p>
              </div>
              <div class="panel-body">
                <hr>
                <form id="insert_permission" method="post" action="<?php echo base_url('backend/insert_permission');?>" class="form-horizontal">
                  <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo $this->lang->line('content');?> <span class="text-danger">*</span></label>
                    <div class="col-sm-8">
                      <input type="text" name="content" class="form-control" placeholder="<?php echo $this->lang->line('ph_content');?>" required />
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo $this->lang->line('rol');?> <span class="text-danger">*</span></label>
                    <div class="col-sm-8">
                      <input type="text" name="rol" class="form-control" placeholder="<?php echo $this->lang->line('ph_rol');?>" required />
                    </div>
                  </div>
                 
                  <hr>

                  <div class="row">
                    <div class="col-sm-9 col-sm-offset-3">
                      <button class="btn btn-success btn-quirk btn-wide mr5"><?php echo $this->lang->line('btn_save');?></button>
                    </div>
                  </div>

                </form>
              </div><!-- panel-body -->
          </div><!-- panel -->

        </div><!-- col-md-6 -->


        <div class="col-md-4">
          <div class="panel panel-inverse-full">
            <div class="panel-heading">
              <h3 class="panel-title">Documentation for help</h3>
            </div>
            <div class="panel-body">
              <p class="nomargin">Write is here step for help to user.</p>
            </div>
          </div><!-- panel -->
          <div class="panel panel-info-full">
            <div class="panel-heading">
              <h3 class="panel-title">Documentation for help</h3>
            </div>
            <div class="panel-body">
              <p class="nomargin">Write is here step for help to user.</p>
            </div>
          </div><!-- panel -->
          <div class="panel panel-danger-full">
            <div class="panel-heading">
              <h3 class="panel-title">Documentation for help</h3>
            </div>
            <div class="panel-body">
              <p class="nomargin">Write is here step for help to user.</p>
            </div>
          </div><!-- panel -->
        </div><!-- col-md-6 -->

      </div><!--row -->


    </div><!-- contentpanel -->
<?php
//MENU
$lang['main_menu'] 			= 'MAIN MENU';
$lang['dashboard']			= 'DASHBOARD';
$lang['publication'] 		= 'PUBLICATIONS';
$lang['add_publication'] 	= 'ADD PUBLICATION';
$lang['articles'] 			= 'ARTICLES';
$lang['books'] 				= 'BOOKS';
$lang['chapter'] 			= 'CHAPTER';
$lang['memoirs'] 			= 'MEMOIRS';
$lang['inception'] 			= 'INCEPTION';
$lang['serial'] 			= 'SERIALS';
$lang['reports'] 			= 'REPORTS';
$lang['user'] 				= 'USERS';
$lang['profile'] 			= 'PROFILES';
$lang['academy'] 			= 'ACADEMY PROFILE';
$lang['rol'] 				= 'ROL';
$lang['permission'] 		= 'PERMISSION';
$lang['countries'] 			= 'COUNTRIES';
$lang['logs'] 				= 'LOGS';
$lang['backups'] 			= 'BACKUPS';
$lang['updates'] 			= 'UPDATES';
$lang['settings'] 			= 'SETTINGS';


//LABELS FORM PUBLICATION
$lang['idp'] 				= 'IDP';
$lang['title'] 				= 'TITLE';
$lang['description'] 		= 'DESCRIPTION';
$lang['keyworks'] 			= 'KEYWORKS';
$lang['year'] 				= 'YEAR';
$lang['pages'] 				= 'PAGES';
$lang['book'] 				= 'BOOK';
$lang['publisher'] 			= 'PUBLISHER';
$lang['authors'] 			= 'AUTHORS';

//LABELS FORM ARTICLES
$lang['ida'] 				= 'IDA';
$lang['number'] 			= 'NUMBER';

//LABELS FORM BOOKS
$lang['idb'] 				= 'IDB';
$lang['target'] 			= 'TARGET';
$lang['edition'] 			= 'EDITION';
$lang['edition_year'] 		= 'EDITION_YEAR';

//LABELS FORM CHAPTER
$lang['idc'] 				= 'IDC';

//LABELS FORM MEMOIRS
$lang['idm'] 				= 'IDM';

//LABELS FORM INCEPTION
$lang['type'] 				= 'TYPE';

//LABELS FORM SERIALS
$lang['key1'] 				= 'KEY1';
$lang['key2'] 				= 'KEY2';
$lang['key3'] 				= 'KEY3';

//LABELS FORM USERS
$lang['username'] 			= 'USERNAME';
$lang['password'] 			= 'PASSWORD';
$lang['status'] 			= 'STATUS';
$lang['first_name'] 		= 'FIRST_NAME';
$lang['last_name'] 			= 'LAST_NAME';
$lang['token'] 				= 'TOKEN';

//LABELS FORM ROL
$lang['name'] 				= 'NAME';
$lang['create'] 			= 'CREATE';

//LABELS FORM PERMISSION
$lang['content'] 			= 'CONTENT';

$lang['btn_save'] 			= 'SAVE';
$lang['btn_add'] 			= 'ADD';


//PLACE HOLDER FORM PUBLICATION
$lang['ph_idp'] 			= 'Type your idp';
$lang['ph_title'] 			= 'Type your title';
$lang['ph_description'] 	= 'Type your description';
$lang['ph_keyworks'] 		= 'Type your keyworks';
$lang['ph_year'] 			= 'Type your year';
$lang['ph_pages'] 			= 'Type your pages';
$lang['ph_book'] 			= 'Type your book';
$lang['ph_publisher'] 		= 'Type your publisher';
$lang['ph_authors'] 		= 'Type your authors';

//PLACE HOLDER FORM ARTICLES
$lang['ph_ida'] 			= 'Type your ida';
$lang['ph_number'] 			= 'Type your number';

//PLACE HOLDER FORM BOOKS
$lang['ph_idb'] 			= 'Type your idb';
$lang['ph_target'] 			= 'Type your target';
$lang['ph_edition'] 		= 'Type your edition';
$lang['ph_edition_year'] 	= 'Type your edition_year';

//PLACE HOLDER CHAPTER
$lang['ph_idc'] 			= 'Type your idc';
$lang['ph_title_book'] 		= 'Type your title_book';

//PLACE HOLDER MEMOIRS 
$lang['ph_idm'] 			= 'Type your idm';

//PLACE HOLDER INCEPTION
$lang['ph_type'] 			= 'Type your type';

//PLACE HOLDER FORM SERIALS
$lang['ph_key1'] 			= 'Type your key1';
$lang['ph_key2'] 			= 'Type your key2';
$lang['ph_key3'] 			= 'Type your key3';

//PLACE HOLDER FORM USERS
$lang['ph_username'] 		= 'Type your username';
$lang['ph_password'] 		= 'Type your password';
$lang['ph_status'] 			= 'Type your status';
$lang['ph_first_name'] 		= 'Type your first_name';
$lang['ph_last_name'] 		= 'Type your last_name';
$lang['ph_token'] 			= 'Type your token';

//PLACE HOLDER FORM ROL
$lang['ph_name'] 			= 'Type your name';
$lang['ph_create'] 			= 'Type your create';

//PLACE HOLDER FORM PERMISSION
$lang['ph_content'] 			= 'Type your content';


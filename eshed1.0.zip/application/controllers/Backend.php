<?php
class Backend extends CI_Controller{
	public function __construct(){
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->helper('menu');
        $this->load->helper('access');
        $this->load->library('session');
        $this->lang->load('backend', 'english');
        $this->load->model('bd_model');
    }
    public function index(){
        $this->load->view('login/signin');
	}
    public function login(){
        $table = 'user';
        $select = 'username';
        $online = 'on';
        $username = $this->input->post('username');
        $password = SHA1($this->input->post('password'));
        $result = $this->bd_model->getLogin($table, $select, $online, $username, $password);
        if(!$result){
            $this->load->view('login/signin');
        }
        else{
            $event = 'login-on';
            $this->update_login($username);
            $this->log($username, $event);
        }
    }
    public function update_login($username){
        $table = 'user';
        $select = 'username';
        $where = $username;
        $data['token'] = SHA1(gethostbyaddr($_SERVER['REMOTE_ADDR']));
        $this->bd_model->getUpdate($table, $select, $where, $data);
        redirect('backend/dashboard');
    }
    public function logout(){
        $username = $this->session->unset_userdata('user_data');
        $this->off_login($username);
    }
    public function off_login($username){
        $table = 'user';
        $select = 'username';
        $where = $username;
        $data['token'] = SHA1(gethostbyaddr($_SERVER['REMOTE_ADDR']));
        $this->bd_model->getUpdate($table, $select, $where, $data);
        $this->session->sess_destroy();
        $this->load->view('login/signin');
    }
    public function log($username, $event){
        $table = 'logs';
        $data['username'] = $username;
        $data['event'] = $event;
        $data['access'] = date('d-m-Y H:i:s');
        $data['ip'] = $_SERVER['REMOTE_ADDR'];
        $data['mac'] = gethostbyaddr($_SERVER['REMOTE_ADDR']);
        $this->bd_model->getInsert($table, $data);
    }
    public function dashboard(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $data['link'] = 'backend/dashboard';
            $data['style'] = 'styles/dashboard';
            $data['script'] = 'scripts/dashboard';
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);
            $this->load->view('backend/footer', $data);
        }
    }
	public function publication(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "publication";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function add_publication(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = 'publication';
            $data['link'] = 'backend/add_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function insert_publication(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "publication";
            $data['idp'] = $this->input->post('idp');
            $data['ids'] = $this->input->post('ids');
            $data['title'] = $this->input->post('title');
            $data['description'] = $this->input->post('description');
            $data['keyworks'] = $this->input->post('keyworks');
            $data['year'] = $this->input->post('year');
            $data['pages'] = $this->input->post('pages');
            $data['book'] = $this->input->post('book');
            $data['publisher'] = $this->input->post('publisher');
            $data['authors'] = $this->input->post('authors');
            $this->bd_model->getInsert($table, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function edit_publication(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "publication";
            $data['link'] = 'backend/edit_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'idp';
            $where = $this->input->get('id');
            $data['query'] = $this->bd_model->whereQuery($table, $select, $where);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function update_publication(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "publication";
            $data['ids'] = $this->input->post('ids');
            $data['title'] = $this->input->post('title');
            $data['description'] = $this->input->post('description');
            $data['keyworks'] = $this->input->post('keyworks');
            $data['year'] = $this->input->post('year');
            $data['pages'] = $this->input->post('pages');
            $data['book'] = $this->input->post('book');
            $data['publisher'] = $this->input->post('publisher');
            $data['authors'] = $this->input->post('authors');            
            $select = 'idp';
            $where = $this->input->post('idp');
            $this->bd_model->getUpdate($table, $select, $where, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function delete_publication(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "publication";
            $data['link'] = 'backend/'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'idp';
            $where = $this->input->get('id');
            $this->bd_model->getDelete($table, $select, $where);
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function articles(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "articles";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function add_articles(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = 'articles';            
            $data['link'] = 'backend/add_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function insert_articles(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $idRanda = "A" . date ("Y") . mt_rand(1000, 5000);
            $idRandp = "P" . date ("Y") . mt_rand(5000, 9999);
            $idRands = "S" . date ("Y") . mt_rand(5000, 9999);
            $table = "articles";
            $data['ida'] = $idRanda;
            $data['idp'] = $idRandp;            
            $data['title'] = $this->input->post('title_articles');
            $data['number'] = $this->input->post('number_articles'); 

            $datap['idp'] = $idRandp;
            $datap['ids'] = $idRands;
            $datap['title'] = $this->input->post('title_publication');
            $datap['description'] = $this->input->post('description_publication');
            $datap['keyworks'] = $this->input->post('keyworks_publication');
            $datap['year'] = $this->input->post('year_publication');
            $datap['pages'] = $this->input->post('pages_publication');
            $datap['book'] = "null";
            $datap['publisher'] = $this->input->post('publisher_publication');
            $datap['authors'] = $this->input->post('authors_publication');

            
            $datas['serial'] = $this->input->post('serial_serial');
            $datas['type'] = $this->input->post('type_serial');
            $datas['key1'] = $this->input->post('key1_serial');
            $datas['key2'] = $this->input->post('key2_serial');
            $datas['key3'] = $this->input->post('key3_serial'); 

            $this->bd_model->getInsert($table, $data);
            $this->bd_model->getInsert('publication', $datap);
            $this->bd_model->getInsert('serial', $datas);        
            

            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function edit_articles(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "articles";
            $data['link'] = 'backend/edit_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'ida';
            $where = $this->input->get('id');
            $data['query'] = $this->bd_model->whereQuery($table, $select, $where);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function update_articles(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "articles";
           $data['idp'] = $this->input->post('idp');
            $data['title'] = $this->input->post('title');
            $data['number'] = $this->input->post('number');            
            $select = 'ida';
            $where = $this->input->post('ida');
            $this->bd_model->getUpdate($table, $select, $where, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function delete_articles(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "articles";
            $data['link'] = 'backend/'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'ida';
            $where = $this->input->get('id');
            $this->bd_model->getDelete($table, $select, $where);
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function books(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "books";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function add_books(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = 'books';
            $data['link'] = 'backend/add_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function insert_books(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "books";
            $data['idb'] = $this->input->post('idb');
            $data['idp'] = $this->input->post('idp');
            $data['target'] = $this->input->post('target');
            $data['edition'] = $this->input->post('edition');
            $data['edition_year'] = $this->input->post('edition_year');            
            $this->bd_model->getInsert($table, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function edit_books(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "books";
            $data['link'] = 'backend/edit_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'idb';
            $where = $this->input->get('id');
            $data['query'] = $this->bd_model->whereQuery($table, $select, $where);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function update_books(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "books";
            $data['idp'] = $this->input->post('idp');
            $data['target'] = $this->input->post('target');
            $data['edition'] = $this->input->post('edition');
            $data['edition_year'] = $this->input->post('edition_year');           
            $select = 'idb';
            $where = $this->input->post('idb');
            $this->bd_model->getUpdate($table, $select, $where, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function delete_books(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "books";
            $data['link'] = 'backend/'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'idb';
            $where = $this->input->get('id');
            $this->bd_model->getDelete($table, $select, $where);
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function chapter(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "chapter";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function add_chapter(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = 'chapter';
            $data['link'] = 'backend/add_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function insert_chapter(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "chapter";
            $data['idc'] = $this->input->post('idc');
            $data['idp'] = $this->input->post('idp');
            $data['title_book'] = $this->input->post('title_book');
            $data['edition'] = $this->input->post('edition');
            $data['number'] = $this->input->post('number');            
            $this->bd_model->getInsert($table, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function edit_chapter(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "chapter";
            $data['link'] = 'backend/edit_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'idc';
            $where = $this->input->get('id');
            $data['query'] = $this->bd_model->whereQuery($table, $select, $where);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function update_chapter(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "chapter";
            $data['idp'] = $this->input->post('idp');
            $data['title_book'] = $this->input->post('title_book');
            $data['edition'] = $this->input->post('edition');
            $data['number'] = $this->input->post('number');            
            $select = 'idc';
            $where = $this->input->post('idc');
            $this->bd_model->getUpdate($table, $select, $where, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function delete_chapter(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "chapter";
            $data['link'] = 'backend/'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'idc';
            $where = $this->input->get('id');
            $this->bd_model->getDelete($table, $select, $where);
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function memoirs(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "memoirs";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function add_memoirs(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = 'memoirs';
            $data['link'] = 'backend/add_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function insert_memoirs(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "memoirs";
            $data['idm'] = $this->input->post('idm');
            $data['idp'] = $this->input->post('idp');
            $data['title'] = $this->input->post('title');            
            $this->bd_model->getInsert($table, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function edit_memoirs(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "memoirs";
            $data['link'] = 'backend/edit_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'idm';
            $where = $this->input->get('id');
            $data['query'] = $this->bd_model->whereQuery($table, $select, $where);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function update_memoirs(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "memoirs";
            $data['idp'] = $this->input->post('idp');
            $data['title'] = $this->input->post('title');            
            $select = 'idm';
            $where = $this->input->post('idm');
            $this->bd_model->getUpdate($table, $select, $where, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function delete_memoirs(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "memoirs";
            $data['link'] = 'backend/'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'idp';
            $where = $this->input->get('id');
            $this->bd_model->getDelete($table, $select, $where);
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function inception(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "inception";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }public function add_inception(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = 'inception';
            $data['link'] = 'backend/add_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function insert_inception(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "inception";
            $data['type'] = $this->input->post('type');            
            $this->bd_model->getInsert($table, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function edit_inception(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "inception";
            $data['link'] = 'backend/edit_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'type';
            $where = $this->input->get('id');
            $data['query'] = $this->bd_model->whereQuery($table, $select, $where);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function update_inception(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "inception";
            $data['type'] = $this->input->post('type');           
            $select = 'type';
            $where = $this->input->post('type');
            $this->bd_model->getUpdate($table, $select, $where, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function delete_inception(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "inception";
            $data['link'] = 'backend/'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'type';
            $where = $this->input->get('id');
            $this->bd_model->getDelete($table, $select, $where);
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function serial(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "serial";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function add_serial(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = 'serial';
            $data['link'] = 'backend/add_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function insert_serial(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "serial";
            $data['serial'] = $this->input->post('serial');
            $data['type'] = $this->input->post('type');
            $data['key1'] = $this->input->post('key1');
            $data['key2'] = $this->input->post('key2');
            $data['key3'] = $this->input->post('key3');            
            $this->bd_model->getInsert($table, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function edit_serial(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "serial";
            $data['link'] = 'backend/edit_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'serial';
            $where = $this->input->get('id');
            $data['query'] = $this->bd_model->whereQuery($table, $select, $where);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function update_serial(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "serial";
            $data['type'] = $this->input->post('type');
            $data['key1'] = $this->input->post('key1');
            $data['key2'] = $this->input->post('key2');
            $data['key3'] = $this->input->post('key3');            
            $select = 'serial';
            $where = $this->input->post('serial');
            $this->bd_model->getUpdate($table, $select, $where, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function delete_serial(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "serial";
            $data['link'] = 'backend/'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'serial';
            $where = $this->input->get('id');
            $this->bd_model->getDelete($table, $select, $where);
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function reports(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "reports";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function user(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "user";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function add_user(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = 'user';
            $data['link'] = 'backend/add_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function insert_user(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "user";
            $data['username'] = $this->input->post('username');
            $data['password'] = $this->input->post('password');
            $data['status'] = $this->input->post('status');
            $data['rol'] = $this->input->post('rol');
            $data['first_name'] = $this->input->post('first_name');
            $data['last_name'] = $this->input->post('last_name');
            $data['token'] = $this->input->post('token');            
            $this->bd_model->getInsert($table, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function edit_user(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "user";
            $data['link'] = 'backend/edit_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'username';
            $where = $this->input->get('id');
            $data['query'] = $this->bd_model->whereQuery($table, $select, $where);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function update_user(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "user";
            $data['password'] = $this->input->post('password');
            $data['status'] = $this->input->post('status');
            $data['rol'] = $this->input->post('rol');
            $data['first_name'] = $this->input->post('first_name');
            $data['last_name'] = $this->input->post('last_name');
            $data['token'] = $this->input->post('token');           
            $select = 'username';
            $where = $this->input->post('username');
            $this->bd_model->getUpdate($table, $select, $where, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function delete_user(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "user";
            $data['link'] = 'backend/'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'username';
            $where = $this->input->get('id');
            $this->bd_model->getDelete($table, $select, $where);
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function profile(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "profile";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function add_profile(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = 'profile';
            $data['link'] = 'backend/add_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function insert_profile(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "profile";
            $data['first_name'] = $this->input->post('first_name');
            $data['last_name'] = $this->input->post('last_name');
            $data['type'] = $this->input->post('type');            
            $this->bd_model->getInsert($table, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function edit_profile(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "profile";
            $data['link'] = 'backend/edit_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'first_name';
            $where = $this->input->get('id');
            $data['query'] = $this->bd_model->whereQuery($table, $select, $where);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function update_profile(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "profile";
            $data['last_name'] = $this->input->post('last_name');
            $data['type'] = $this->input->post('type');            
            $select = 'first_name';
            $where = $this->input->post('first_name');
            $this->bd_model->getUpdate($table, $select, $where, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function delete_profile(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "profile";
            $data['link'] = 'backend/'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'first_name';
            $where = $this->input->get('id');
            $this->bd_model->getDelete($table, $select, $where);
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function academy(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "academy";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function add_academy(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = 'academy';
            $data['link'] = 'backend/add_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function insert_academy(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "academy";
            $data['type'] = $this->input->post('type');            
            $this->bd_model->getInsert($table, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function edit_academy(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "academy";
            $data['link'] = 'backend/edit_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'type';
            $where = $this->input->get('id');
            $data['query'] = $this->bd_model->whereQuery($table, $select, $where);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function update_academy(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "academy";
            $data['type'] = $this->input->post('type');            
            $select = 'type';
            $where = $this->input->post('type');
            $this->bd_model->getUpdate($table, $select, $where, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function delete_academy(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "academy";
            $data['link'] = 'backend/'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'type';
            $where = $this->input->get('id');
            $this->bd_model->getDelete($table, $select, $where);
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function rol(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "rol";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function add_rol(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = 'rol';
            $data['link'] = 'backend/add_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function insert_rol(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "rol";
            $data['name'] = $this->input->post('name');
            $data['create'] = $this->input->post('create');            
            $this->bd_model->getInsert($table, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function edit_rol(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "rol";
            $data['link'] = 'backend/edit_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'name';
            $where = $this->input->get('id');
            $data['query'] = $this->bd_model->whereQuery($table, $select, $where);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function update_rol(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "rol";
            $data['name'] = $this->input->post('name');
            $data['create'] = $this->input->post('create');            
            $select = 'name';
            $where = $this->input->post('name');
            $this->bd_model->getUpdate($table, $select, $where, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function delete_rol(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "rol";
            $data['link'] = 'backend/'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'name';
            $where = $this->input->get('id');
            $this->bd_model->getDelete($table, $select, $where);
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function permission(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "permission";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function add_permission(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = 'permission';
            $data['link'] = 'backend/add_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function insert_permission(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "permission";
            $data['content'] = $this->input->post('content');
            $data['rol'] = $this->input->post('rol');            
            $this->bd_model->getInsert($table, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function edit_permission(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "permission";
            $data['link'] = 'backend/edit_'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'content';
            $where = $this->input->get('id');
            $data['query'] = $this->bd_model->whereQuery($table, $select, $where);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function update_permission(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "permission";
            $data['content'] = $this->input->post('content');
            $data['rol'] = $this->input->post('rol');            
            $select = 'content';
            $where = $this->input->post('content');
            $this->bd_model->getUpdate($table, $select, $where, $data);
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function delete_permission(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "permission";
            $data['link'] = 'backend/'.$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $select = 'content';
            $where = $this->input->get('id');
            $this->bd_model->getDelete($table, $select, $where);
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function countries(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "countries";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function logs(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "logs";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function backups(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "backups";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function new_backup()
    {
        date_default_timezone_set("America/Mexico_city");
        $this->load->dbutil();
        $date = date("dmY_His");
        $prefs = array(
            'tables'      => array(),
            'ignore'      => array(),
            'format'      => 'zip',
            'filename'    => 'backup_'.$date.'.sql',
            'add_drop'    => TRUE,
            'add_insert'  => TRUE,
            'newline'     => "\n");
        $backup = $this->dbutil->backup($prefs); 
        $this->load->helper('file');
        write_file('./backups/backup_'.$date.'.zip', $backup);
        redirect('backend/backups');
    }
    public function backup_files(){
        $directorio = opendir(".");
        while ($archivo = readdir($directorio)){
            if (is_dir($archivo)){
                echo "[".$archivo . "]<br />";
            }
            else{
                echo $archivo . "<br />";
            }
        }
    }
    public function updates(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "updates";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
    public function update_check(){
        redirect('backend/updates');
    }
    public function update_now(){
        redirect('backend/updates');
    }
    public function settings(){
        $session = $this->session->userdata('user_data');
        $empty = "";
        if($session == $empty){
            $this->load->view('login/signin');
        }
        else{
            $table = "settings";
            $data['link'] = "backend/".$table;
            $data['style'] = 'styles/'.$table;
            $data['script'] = 'scripts/'.$table;
            $data['query'] = $this->bd_model->getQuery($table);
            $this->load->view('backend/header', $data);
            $this->load->view('backend/head');
            $this->load->view('backend/section', $data);   
            $this->load->view('backend/footer', $data);
        }
    }
}